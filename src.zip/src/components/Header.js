import React, { useEffect, useState } from "react";
import "../styles/Header.css"
import SearchIcon from "@mui/icons-material/Search"
import { Link, redirect, useNavigate } from 'react-router-dom'
import { ShoppingBasket } from "@mui/icons-material";
import { useStateValue } from "../StateProvider";
import { auth, db, database } from "../firebase";

import { doc, setDoc, getDoc, addDoc, collection } from 'firebase/firestore';
import { addData } from "../utils";
import { getDatabase, ref, set, onValue, get, child } from "firebase/database";
function Header() {


    const [{ basket, loggedinuser }, dispatch] = useStateValue()
    const [searchText, setSearchText] = useState("");
    let username = ""
    if (loggedinuser) {
        username = loggedinuser.username
    }




    /* const fetchData = async function () {
          if (!loggedinuser) {
              const docRef = await doc(db, "userCart", "cart")
              const docSnap = getDoc(docRef)
  
              console.log("hello")
              docSnap.forEach(doc => {
                  console.log(doc.data());
              })
  
  
  
          }
      }
      useEffect(() => {
          fetchData();
      }
          , [])
      
  */

    //console.log(basket)
    /* const username = () => {
         if (loggedinuser) {
             const temp = loggedinuser.email.split('@')[0];
 
             return temp;
 
 
         }
     }
 
     const logoutUser = () => {
         if (loggedinuser) {
             auth.signOut();
 
         }
     }
     */



    /*  useEffect(() => {
          addData(loggedinuser, basket);
      }, [basket])
  
  */
    const navigate = useNavigate();
    const handleKeyDown = (event) => {
        if (event.key === 'Enter') {
            navigate(`/product/search?q=${searchText}`)
        }
    }

    const logoutUser = () => {
        dispatch({
            type: 'SET_LOGIN',
            user: null,
            token: null
        }
        )
    }
    return (

        < nav className="header" >

            <Link to='/' className="onhover">
                <img className="header__logo" alt="logo" src="http://pngimg.com/uploads/amazon/amazon_PNG11.png" onClick={() => setSearchText("")} />
            </Link>

            <div className="header__search">
                <input type="text" className="header__searchInput" value={searchText} onKeyDown={handleKeyDown} onChange={event => setSearchText(event.target.value)} />
                <Link to={`/product/search?q=${searchText}`}>
                    <SearchIcon className="header__searchIcon" />
                </Link>
            </div>

            <div className="header__nav ">
                <Link to={!loggedinuser && "/login"} className="header__link onhover">
                    <div onClick={() => { logoutUser(loggedinuser) }} className="header__option">
                        <span className="header__optionLineOne">Hello, {loggedinuser ? username : "User"}</span>
                        <span className="header__optionLineTwo">{loggedinuser ? 'Sign Out' : 'Sign In'}</span>

                    </div>
                </Link>

                <Link to="/" className="header__link onhover" >
                    <div className="header__option ">
                        <span className="header__optionLineOne">Returns</span>
                        <span className="header__optionLineTwo">& Orders</span>

                    </div>
                </Link>

                <Link to="/" className="header__link onhover">
                    <div className="header__option" >
                        <span className="header__optionLineOne">You</span>
                        <span className="header__optionLineTwo">Prime</span>

                    </div>
                </Link>

                <Link to="/checkout" className="header__link onhover">
                    <div className="header__optionBasket">
                        <ShoppingBasket />
                        <span className="header__optionLineTwo header__productCount">{basket?.length}</span>
                    </div>
                </Link>
            </div>
        </nav >


    )
}

export default Header