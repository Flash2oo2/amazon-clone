import React, { useState } from "react";
import '../styles/Login.css'
import { Link, useNavigate } from "react-router-dom";
import { useStateValue } from '../StateProvider';
import { auth } from '../firebase'
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from "firebase/auth";

function Login() {
    const [{ basket, loggedinuser }, dispatch] = useStateValue()
    const [pageType, setPageType] = useState("login");
    const history = useNavigate()
    const [userName, setUserName] = useState('')
    const [useremail, setUserEmail] = useState('')
    const [userpassword, setUserPassword] = useState('')
    const isLogin = pageType === "login";
    const isRegister = pageType === "register";

    // const loginuser = async event => {
    //     event.preventDefault()
    //     await signInWithEmailAndPassword(auth, useremail, userpassword)
    //         .then((auth) => {
    //             history('/')
    //         }
    //         )
    //         .catch(e => alert(e.message))
    // }

    // const signupuser = async event => {
    //     event.preventDefault()
    //     await createUserWithEmailAndPassword(auth, useremail, userpassword)
    //         .then(auth => {
    //             history('/')
    //         }

    //         )
    //         .catch(e => alert(e.message))

    // }

    const resetform = () => {
        setUserName("");
        setUserEmail("");
        setUserPassword("");
    }

    const loginuser = async event => {
        event.preventDefault();
        const loggedInResponse = await fetch("http://localhost:5000/api/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                email: useremail,
                password: userpassword
            })
        })
        const loggedIn = await loggedInResponse.json();
        resetform();

        if (loggedIn) {
            dispatch({
                type: 'SET_LOGIN',
                user: loggedIn.user,
                token: loggedIn.token
            })

            history("/");
        }
        else {
            alert("AUTHENTICATION FAILED");
        }

    }

    const signupuser = async event => {
        event.preventDefault();
        const loggedInResponse = await fetch("http://localhost:5000/api/auth/register", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                username: userName,
                email: useremail,
                password: userpassword
            })
        })
        resetform();
        const registerUser = await loggedInResponse.json();
        if (registerUser) {
            setPageType("Login");
        }
        else {
            alert("REGISTRATION FAILED");
        }


    }
    return (
        <div className="login">
            <Link>
                <img className="login__logo"
                    alt=""
                    src="https://upload.wikimedia.org/wikipedia/commons/a/a9/Amazon_logo.svg" />
            </Link>
            <div className="login__container">
                <h1>Sign in</h1>
                <form>
                    {pageType === "register" &&
                        (<><h5>Username</h5>
                            <input value={userName} onChange={event => setUserName(event.target.value)} type="text" />
                        </>)}
                    <h5>E-mail</h5>
                    <input value={useremail} onChange={event => setUserEmail(event.target.value)} type="email" />
                    <h5>Password</h5>
                    <input value={userpassword} onChange={event => setUserPassword(event.target.value)} type="password" />
                    {pageType === "login" && <button onClick={loginuser} type="submit" className="login__signInButton hover__button">Sign In</button>}
                    <br></br>

                    <p> By signing-in , you agree to Amazon's Terms & Conditions</p>

                    <div
                        style={{ color: "blue", }}
                        onClick={() => {
                            setPageType(isLogin ? "register" : "login");
                            resetform();
                        }
                        }>
                        {pageType === "login" ? <p>New to Amazon? Create Account </p> : <p>Already have an Account, Please Sign In </p>}
                    </div>
                    {pageType === "register" && <button onClick={signupuser} className="login__registerButton hover__button">Create your Amazon Account</button>}
                </form>
            </div >

        </div >

    )
}

export default Login