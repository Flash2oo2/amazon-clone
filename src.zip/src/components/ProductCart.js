
import React, { useState, useEffect } from "react";
import '../styles/ProductCart.css'
import { useStateValue } from "../StateProvider";
import { Rating } from "@mui/material";
import { writeUserData } from "../utils";
function ProductCart({ id, title, image, price, rating, setToggle, toggle }) {

    const [{ basket, loggedinuser }, dispatch] = useStateValue();


    const removeItem = () => {
        dispatch({
            type: "REMOVE_FROM_CART",
            id: id
        })
    }
    return (

        <div className="productcart">
            <img className="productcart__image" src={image} alt="" />
            <div className="productcart__info">
                <p className="productcart__title">{title}</p>
                <p className="productcart__price">${price}</p>


                <div className="productcart__rating">
                    <Rating name="" value={parseFloat(rating)} size="small" precision={0.1} readOnly />
                    <span className="rating__text">{rating}</span>
                </div>
                <button className="hover__button" onClick={async () => {
                    removeItem()
                    await setToggle((prevState) => prevState + 1)
                }}>Remove from cart</button>
            </div>
        </div>
    )


}

export default ProductCart