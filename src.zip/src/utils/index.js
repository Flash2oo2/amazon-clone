
import { db, auth, database } from "../firebase";
import { getDatabase, ref, set, onValue, get, child } from "firebase/database";

export const username = (loggedinuser) => {
    if (loggedinuser) {
        const temp = loggedinuser.email.split('@')[0];

        return temp;


    }
}

export const logoutUser = (loggedinuser) => {
    if (loggedinuser) {
        auth.signOut();

    }
}




export const writeUserData = (loggedinuser, basket) => {

    set(ref(database, 'users/' + loggedinuser.uid),
        basket.length !== 0 ?
            {

                ...basket
            }
            :
            {}
    );
    console.log("done")
}
